package com.ssafy.cherish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CherishApplication {

	public static void main(String[] args) {
		SpringApplication.run(CherishApplication.class, args);
	}

}
