package com.ssafy.cherish;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CherishApplicationTests {

	@Test
	void contextLoads() {
	}

}
