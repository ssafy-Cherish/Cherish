package com.ssafy.cherish.model.service;

import com.ssafy.cherish.model.dto.MemberDto;

import java.util.List;
import java.util.Map;

public interface MemberService {
	int joinMember(MemberDto memberDto);
}
